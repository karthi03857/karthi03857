import sys
import os
import streamlit as st
import json
import secrets
import hashlib
from datetime import datetime
import time
import smtplib
from email.mime.multipart import MIMEMultipart
from email.mime.text import MIMEText
from adhar.verify import verhoeff_validate  # Import Aadhaar validation function
from dotenv import load_dotenv



# Ensure the current directory is included in the module path
sys.path.append(os.path.abspath(os.path.dirname(__file__)))

# Import modules
from models.blockchain import BlockchainSystem
from models.user import User
from utils.validation import validate_email, validate_phone, validate_password, validate_aaa_card
from utils.encryption import generate_salt, hash_password_with_salt

# Ensure the `data` directory exists
if not os.path.exists('data'):
    os.makedirs('data')

load_dotenv()

EMAIL = os.getenv("EMAIL")
PASSWORD = os.getenv("PASSWORD")

class UserManager:
    
    def __init__(self, blockchain):
        self.users = {}
        self.token_to_user = {}
        self.blockchain = blockchain
        self.load_users()

    def save_users(self):
        users_data = {email: user.to_dict() for email, user in self.users.items()}
        with open('data/users.json', 'w') as f:
            json.dump(users_data, f, indent=4)

        with open('data/tokens.json', 'w') as f:
            json.dump(self.token_to_user, f, indent=4)

    def load_users(self):
        try:
            with open('data/users.json', 'r') as f:
                users_data = json.load(f)
                self.users = {}
                for email, data in users_data.items():
                    user = User(**data)
                    self.users[email] = user

            with open('data/tokens.json', 'r') as f:
                self.token_to_user = json.load(f)
        except FileNotFoundError:
            pass

    def register_user(self, name, email, phone, username, password, aaa_card):
        validate_email(email)
        validate_phone(phone)
        validate_password(password)
        validate_aaa_card(aaa_card)

        if email in self.users:
            raise ValueError("Email already registered")
        if aaa_card in self.users:
            raise ValueError("This AAA Number already Registered!!!")
        if name in self.users:
            raise ValueError("Name Already Exists!!")

        salt = generate_salt()
        password_hash = hash_password_with_salt(aaa_card, salt)
        token_id = secrets.token_urlsafe(16)
        secret_key = secrets.token_hex(8)

        user = User(
            name=name,
            email=email,
            phone=phone,
            username=username,
            password_hash=f"{salt}:{password_hash}",
            aaa_card=aaa_card,
            token_id=token_id,
            secret_key=secret_key,
            accounts=[username],
            profile_data={"created_at": str(datetime.now())},
            posts=[],
            videos=[],
            stories=[]
        )

        self.users[email] = user
        self.token_to_user[token_id] = email
        self.save_users()
        return user

    def login(self, token_id):
        if token_id not in self.token_to_user:
            raise ValueError("Invalid token ID")
        email = self.token_to_user[token_id]
        return self.users[email]
    
    def search_by_secret_key(self, secret_key):
        for user in self.users.values():
            if user.secret_key == secret_key:
                return user.accounts, user.profile_data
        return [], None
    def delete_account(self, user_email):
        """
        Delete a user account and associated data including blockchain records, tokens, and files.
        
        Args:
            user_email (str): Email of the user account to delete
            
        Returns:
            bool: True if successful, False if deletion failed
            
        Raises:
            ValueError: If user email not found or validation fails
        """
        try:
            # Validate user exists
            if user_email not in self.users:
                raise ValueError(f"No account found for email: {user_email}")
                
            user = self.users[user_email]
                
            # Delete user's token from token mapping
            tokens_to_delete = []
            for token, email in self.token_to_user.items():
                if email == user_email:
                    tokens_to_delete.append(token)
                    
            for token in tokens_to_delete:
                del self.token_to_user[token]
                
            # Delete any user content
            try:
                # Remove user's posts
                for post in user.posts:
                    if 'image_path' in post:
                        # Delete post image if exists
                        try:
                            os.remove(post['image_path'])
                        except OSError:
                            pass
                            
                # Remove user's videos
                for video in user.videos:
                    if 'video_path' in video:
                        try:
                            os.remove(video['video_path'])
                        except OSError:
                            pass
                            
                # Remove user's stories
                for story in user.stories:
                    if 'media_path' in story:
                        try:
                            os.remove(story['media_path'])
                        except OSError:
                            pass
                            
            except Exception as e:
                print(f"Warning: Error cleaning up user content: {str(e)}")
                # Continue with account deletion even if content cleanup fails
                
            # Remove blockchain records if they exist
            if hasattr(self, 'blockchain'):
                try:
                    self.blockchain.remove_user_records(user_email)
                except Exception as e:
                    print(f"Warning: Error removing blockchain records: {str(e)}")
                    
            # Finally delete user from users dict
            del self.users[user_email]
            
            # Save updated user and token data
            self.save_users()
            
            return True
            
        except Exception as e:
            print(f"Critical error during account deletion: {str(e)}")
            return False
    def find_token(self, token_id):
        """
        Check if a token ID exists in the system
        
        Args:
            token_id (str): The token ID to check
            
        Returns:
            bool: True if token exists, False otherwise
        """
        try:
            return token_id in self.token_to_user
        except Exception as e:
            raise ValueError(f"Error checking token: {str(e)}")
    def create_additional_account(self, token_id, new_username):
        """
        Create an additional account for an existing user
        
        Args:
            token_id (str): The token ID of the existing user
            new_username (str): The username for the new account
            
        Returns:
            User: Updated user object
        """
        try:
            # Get the email associated with the token
            email = self.token_to_user.get(token_id)
            if not email:
                raise ValueError("Invalid token ID")
                
            # Get the user object
            user = self.users.get(email)
            if not user:
                raise ValueError("User not found")
                
            # Check if username already exists
            for existing_user in self.users.values():
                if new_username in existing_user.accounts:
                    raise ValueError("Username already taken")
                    
            # Add the new account to the user's accounts list
            user.accounts.append(new_username)
            
            # Save the updated user data
            self.save_users()
            
            return user
            
        except Exception as e:
            raise ValueError(f"Error creating additional account: {str(e)}")
# Custom CSS for styling
def apply_custom_style():
    st.markdown("""
        <style>
        body {
            font-family: 'Roboto', sans-serif;
            background-color: #f0f2f5;
            color: #333;
        }
        .main {
            padding: 2rem;
        }
        .stTitle {
            color: #1E88E5;
            font-size: 2.5rem !important;
            font-weight: 700 !important;
            margin-bottom: 2rem !important;
            text-align: center;
        }
        .css-1d391kg {
            background-color: #f8f9fa;
            padding: 2rem 1rem;
        }
        .nav-button {
            background-color: transparent;
            border: none;
            color: #1E88E5;
            padding: 0.5rem 1rem;
            width: 100%;
            text-align: left;
            cursor: pointer;
            margin: 0.25rem 0;
            border-radius: 5px;
            transition: all 0.3s ease;
            font-size: 1rem;
        }
        .nav-button:hover {
            background-color: #e3f2fd;
        }
        .nav-button.active {
            background-color: #1E88E5;
            color: white;
        }
        .stTextInput > div > div > input {
            background-color: #fff;
            border: 1px solid #e0e0e0;
            border-radius: 5px;
            padding: 0.5rem;
        }
        .stButton > button {
            background-color: #1E88E5;
            color: white;
            border: none;
            border-radius: 5px;
            padding: 0.5rem 2rem;
            font-weight: 600;
            width: 100%;
        }
        .stButton > button:hover {
            background-color: #1976D2;
        }
        .post-card {
            background-color: white;
            border-radius: 10px;
            padding: 1.5rem;
            margin-bottom: 1rem;
            box-shadow: 0 2px 4px rgba(0,0,0,0.1);
        }
        .profile-info {
            background-color: white;
            border-radius: 10px;
            padding: 2rem;
            margin-bottom: 1rem;
            box-shadow: 0 2px 4px rgba(0,0,0,0.1);
        }
        </style>
    """, unsafe_allow_html=True)

def create_static_navigation():
    if not st.session_state.get('logged_in', False):
        menu_options = [("🏠 Home", "Home")]
    else:
        menu_options = [
            ("🏠 Home", "Home"),
            ("👤 Profile", "Profile"),
            ("⬆️ Upload Content", "Upload Content"),
            ("🔍 Explore", "Explore"),
            ("Search","Search"),
            ("add account","add account"),
            ("🚪 Logout", "Logout")
        ]

    for display_name, menu_name in menu_options:
        is_active = st.session_state.get('current_page') == menu_name
        if st.sidebar.button(display_name, key=f"nav_{menu_name}"):
            st.session_state.current_page = menu_name
            st.rerun()

def reset_form_state():
    """Reset all form-related session state variables"""
    if 'token_id' in st.session_state:
        del st.session_state.token_id
    if 'name' in st.session_state:
        del st.session_state.name
    if 'email' in st.session_state:
        del st.session_state.email
    if 'phone' in st.session_state:
        del st.session_state.phone
    if 'username' in st.session_state:
        del st.session_state.username
    if 'password' in st.session_state:
        del st.session_state.password
    if 'aaa_card' in st.session_state:
        del st.session_state.aaa_card
# Function to load external CSS from utils/profile.css
def load_css(file_name):
    css_path = os.path.join(os.path.dirname(os.path.abspath(__file__)),"utils",file_name)  # Get full path
    if not os.path.exists(css_path):  
        return  # Stop function if file is missing

    with open(css_path, "r") as f:
        css = f.read()
    st.markdown(f"<style>{css}</style>", unsafe_allow_html=True)

def load_js(js_file):
    """Loads an external JavaScript file in Streamlit."""
    st.components.v1.html(f"""
        <script src="/static/{js_file}"></script>
    """, height=50)

def send_email(receiver_email, token_id,name):
    sender_email = EMAIL  # Replace with your email
    sender_password = PASSWORD  # Use App Password if using Gmail

    subject = "Your Registration Credentials"
    body = f"""
    Hello {name},

    Welcome to Secure Sphere!
    Thank you for being a valued part of our community. We appreciate your presence!
    Here are your credentials:

    - Token ID: {token_id}

    Please keep these details secure.

    Regards,
    Secure_Sphere
    securesphere3@gmail.com

    """

    msg = MIMEMultipart()
    msg['From'] = sender_email
    msg['To'] = receiver_email
    msg['Subject'] = subject
    msg.attach(MIMEText(body, 'plain'))

    try:
        server = smtplib.SMTP("smtp.gmail.com", 587)  # Use your SMTP server
        server.starttls()
        server.login(sender_email, sender_password)
        server.sendmail(sender_email, receiver_email, msg.as_string())
        server.quit()
        st.success("Email sent successfully!")
    except Exception as e:
        st.error(f"Error sending email: {e}")

def send_email_otp(receiver_email, otp, sender_password):
    """Send OTP via email using Gmail SMTP"""
    sender_email = EMAIL  # Replace with your Gmail address
    sender_password = PASSWORD
    try:
        message = MIMEMultipart()
        message["From"] = sender_email
        message["To"] = receiver_email
        message["Subject"] = "Your OTP for Account Creation"

        body = f"Your OTP is: {otp}\nThis OTP will expire in 2 minutes."
        message.attach(MIMEText(body, "plain"))

        server = smtplib.SMTP("smtp.gmail.com", 587)
        server.starttls()
        server.login(sender_email, sender_password)
        server.send_message(message)
        server.quit()
        return True
    except Exception as e:
        print(f"Failed to send email: {str(e)}")
        return False
    
def reset_otp_state():
    """Reset OTP-related session state variables"""
    st.session_state.otp_sent = False
    st.session_state.otp_verified = False
    st.session_state.generated_otp = None
    st.session_state.otp_timestamp = None
    st.session_state.otp_attempts = 0

def upload_content_section():
  st.markdown("""
           <style>
    /* Upload Section Styling */
    .upload-section {
        background-color: #f8f9fa;
        padding: 2rem;
        border-radius: 10px;
        box-shadow: 0 4px 6px rgba(0, 0, 0, 0.1);
        margin: 1rem 0;
    }

    /* Text Input Styling */
    .stTextArea textarea, .stTextInput input {
        font-size: 18px; /* Larger Font */
        font-weight: bold; /* Bold for better visibility */
        border-radius: 8px;
        border: 2px solid #e0e0e0;
        padding: 12px;
    }

    /* Button Styling */
    .stButton button {
        font-size: 20px; /* Larger Button Text */
        font-weight: bold;
        border-radius: 20px;
        padding: 0.7rem 2.5rem;
        background-color: #4CAF50;
        color: white;
        border: none;
        transition: all 0.3s ease;
        cursor: pointer;
    }

    /* Button Hover Effect */
    .stButton button:hover {
        background-color: #45a049;
        box-shadow: 0 4px 12px rgba(0, 0, 0, 0.2);
        transform: scale(1.05);
    }

    /* Section Headers */
    .content-type-header {
        color: #2c3e50;
        font-size: 22px; /* Bigger header */
        font-weight: bold;
        margin-bottom: 1rem;
    }

    /* General Enhancements */
    body {
        font-size: 18px; /* Increased default font size */
        color: #333; /* Darker text for readability */
    }
</style>
""", unsafe_allow_html=True)

def main():
    apply_custom_style()

    
    # Initialize session state variables
    if 'blockchain' not in st.session_state:
        st.session_state.blockchain = BlockchainSystem()
        st.session_state.user_manager = UserManager(st.session_state.blockchain)
    if 'current_page' not in st.session_state:
        st.session_state.current_page = "Welcome"
    if 'logged_in' not in st.session_state:
        st.session_state.logged_in = False
    if 'redirect_time' not in st.session_state:
        st.session_state.redirect_time = None  
    if 'logout_clicked' not in st.session_state:
        st.session_state.logout_clicked = False
    if "otp_sent" not in st.session_state:
        st.session_state.otp_sent = False  # Track if OTP is sent
    if "generated_otp" not in st.session_state:
        st.session_state.generated_otp = None  # Store hashed OTP
    if "otp_timestamp" not in st.session_state:
        st.session_state.otp_timestamp = None  # Store OTP generation time
    if "otp_attempts" not in st.session_state:
        st.session_state.otp_attempts = 0  # Track failed attempts
    if "otp_verified" not in st.session_state:
        st.session_state.otp_verified = False  # Track verification status
    if "token_valid" not in st.session_state:
        st.session_state.token_valid = False  # Track token validation
    if 'current_email' not in st.session_state:
        st.session_state.current_email = None

    menu = st.session_state.current_page
    
    if menu == "Welcome":
        # Welcome page with login/register options
        load_js("welcome.js")
        st.title("🌟 Welcome to SECURE SPHERE")
        
        with st.container():
            st.markdown("""
                ### Empowering Social Connections with Blockchain Security
                
                Join our secure platform to experience:
                - Enhanced privacy protection
                - Secure social interactions
                - Blockchain-backed security
                - Trusted connections
            """)
            
            st.write("")
            st.write("")
            
            col1, col2, col3 = st.columns([1, 2, 1])
            with col2:
                if st.button("🔑 Login", use_container_width=True):
                    st.session_state.current_page = "Login"
                    st.rerun()
                
                st.write("")
                
                if st.button("📝 Create Account", use_container_width=True):
                    st.session_state.current_page = "Register"
                    st.rerun()
                    
    elif menu == "Login":
        st.title("👋 Welcome Back")
        
        with st.container():
            token_id = st.text_input("Enter Token ID", key="token_id")
            
            col1, col2 = st.columns([1, 4])
            with col1:
                if st.button("← Back"):
                    st.session_state.current_page = "Welcome"
                    reset_form_state()
                    st.rerun()
            with col2:
                if st.button("Login", use_container_width=True):
                    try:
                        user = st.session_state.user_manager.login(token_id)
                        st.session_state.user = user
                        st.session_state.logged_in = True
                        
                        success_container = st.empty()
                        success_container.success(f"Welcome back, {user.name}!")
                        time.sleep(2)
                        st.session_state.current_page = "Profile"
                        reset_form_state()
                        st.rerun()
                        
                    except ValueError as e:
                        st.error(str(e))
                        
    elif menu == "Register":
        st.title("📝 Create New Account")

        with st.form("register_form"):
            name = st.text_input("Name", key="name")
            email = st.text_input("Email", key="email")
            phone = st.text_input("Phone", key="phone")
            username = st.text_input("Username", key="username")
            password = st.text_input("Password", type="password", key="password")
            aadhaar = st.text_input("Aadhaar Number", key="aadhaar")

            col1, col2 = st.columns([1, 4])
            with col1:
                if st.form_submit_button("← Back"):
                    st.session_state.current_page = "Welcome"
                    reset_form_state()
                    st.rerun()

            with col2:
                if st.form_submit_button("Register", use_container_width=True):
                    try:
                        # Validate Aadhaar Number using imported function
                        if not verhoeff_validate(aadhaar):
                            st.error("❌ Invalid Aadhaar number! Please enter a valid 12-digit Aadhaar.")
                            st.stop()

                        user = st.session_state.user_manager.register_user(
                            name, email, phone, username, password, aadhaar
                        )
                        st.success(f"Registration successful!")
                        
                        # Send credentials via Email
                        send_email(email, user.token_id,user.name)

                        time.sleep(3)
                        st.session_state.user = user
                        st.session_state.current_page = "Login"

                        reset_form_state()
                        st.rerun()

                    except ValueError as e:
                        st.error(str(e))

    
    if st.session_state.logged_in:
        pages = ["Profile", "Upload Content","Explore","Search","add account", "Logout"]
        for page in pages:
            if st.sidebar.button(page):
                st.session_state.current_page = page
                st.rerun()

    # After Login: Uploading Options
    # Only show "Upload Content" when the user selects it from the menu

    if menu == "Upload Content" and st.session_state.get("logged_in"):
        # Custom CSS for styling
        st.markdown("<h1 style='text-align: center; font-size: 40px; color:white; margin-bottom: 2rem;'>Share Your Content</h1>", unsafe_allow_html=True)
        st.markdown("<p style='text-align: center; font-size: 22px; color: #ccc; margin-bottom: 3rem;'>Express yourself through posts, videos, and stories</p>", unsafe_allow_html=True)

        # Create tabs for different upload types
        tabs = st.tabs(["📝 **Posts**", "🎥 **Videos**", "📖 **Stories**"])

        # Posts Tab
        with tabs[0]:
            with st.container():
                st.markdown('<div class="upload-section">', unsafe_allow_html=True)
                st.markdown('<p class="content-type-header" style="font-size: 28px;">📝 Create a New Post</p>', unsafe_allow_html=True)
                post_content = st.text_area("✍️ What's on your mind?", height=150, placeholder="Share your thoughts with the world...", label_visibility="collapsed")
                col1, col2, col3 = st.columns([1, 1, 1])
                with col2:
                    if st.button("📤 **Share Post**", use_container_width=True):
                        if post_content.strip():
                            st.session_state.user.add_post(post_content)
                            st.session_state.user_manager.save_users()
                            st.success("🎉 **Post shared successfully!**")
                        else:
                            st.warning("⚠️ **Please write something before posting!**")
                st.markdown('</div>', unsafe_allow_html=True)

        # Videos Tab
        with tabs[1]:
            with st.container():
                st.markdown('<div class="upload-section">', unsafe_allow_html=True)
                st.markdown('<p class="content-type-header" style="font-size: 28px;">🎬 Share a Video</p>', unsafe_allow_html=True)
                video_url = st.text_input("📹 **Video URL**", placeholder="Paste your video URL here...", label_visibility="collapsed")
                col1, col2, col3 = st.columns([1, 1, 1])
                with col2:
                    if st.button("🎬 **Share Video**", use_container_width=True):
                        if video_url.strip():
                            st.session_state.user.add_video(video_url)
                            st.session_state.user_manager.save_users()
                            st.success("🎉 **Video shared successfully!**")
                        else:
                            st.warning("⚠️ **Please enter a video URL!**")
                st.markdown('</div>', unsafe_allow_html=True)

        # Stories Tab
        with tabs[2]:
            with st.container():
                st.markdown('<div class="upload-section">', unsafe_allow_html=True)
                st.markdown('<p class="content-type-header" style="font-size: 28px;">📖 Create a Story</p>', unsafe_allow_html=True)
                story_content = st.text_area("📜 **Write your story**", height=200, placeholder="Once upon a time...", label_visibility="collapsed")
                col1, col2, col3 = st.columns([1, 1, 1])
                with col2:
                    if st.button("📝 **Share Story**", use_container_width=True):
                        if story_content.strip():
                            st.session_state.user.add_story(story_content)
                            st.session_state.user_manager.save_users()
                            st.success("🎉 **Story shared successfully!**")
                        else:
                            st.warning("⚠️ **Please write your story before sharing!**")
                st.markdown('</div>', unsafe_allow_html=True)


    elif menu == "Profile":
        # Custom CSS for styling    
        load_css("profile.css")
        
        if 'user' in st.session_state and st.session_state.user:
            user = st.session_state.user
            
            # Profile Header
            st.markdown('<div class="profile-header">', unsafe_allow_html=True)
            col1, col2 = st.columns([1, 3])
            with col1:
                st.image("https://via.placeholder.com/150", width=150)
            with col2:
                st.title(f"👤 {user.username}")
                st.write("Manage and view your profile details")
            st.markdown('</div>', unsafe_allow_html=True)
            
            # Profile Stats in Columns
            col1, col2, col3 = st.columns(3)
            with col1:
                st.markdown('<div class="stat-box">', unsafe_allow_html=True)
                st.metric("Posts", len(user.posts))
                st.markdown('</div>', unsafe_allow_html=True)
            with col2:
                st.markdown('<div class="stat-box">', unsafe_allow_html=True)
                st.metric("Videos", len(user.videos))
                st.markdown('</div>', unsafe_allow_html=True)
            with col3:
                st.markdown('<div class="stat-box">', unsafe_allow_html=True)
                st.metric("Stories", len(user.stories))
                st.markdown('</div>', unsafe_allow_html=True)

            # User Details Card
            with st.expander("📋 Personal Information", expanded=True):
                col1, col2 = st.columns(2)
                with col1:
                    st.info(f"**Username:** {user.username}")
                    st.info(f"**User_key:** {user.secret_key}")
                
            # Delete Account Section
            # Delete Account Section
            st.markdown("---")
            delete_cols = st.columns([2, 1])

            with delete_cols[0]:
                st.warning("⚠️ **Warning:** Deleting your account will permanently remove all your data and cannot be undone.")

            with delete_cols[1]:
                if not st.session_state.get('show_delete_confirm'):
                    if st.button("🗑️ Delete Account", key="initial_delete"):
                        st.session_state.show_delete_confirm = True
                        st.rerun()

            # Show confirmation dialog if delete was clicked
            if st.session_state.get('show_delete_confirm'):
                confirm_cols = st.columns([1, 1, 1])
                
                with confirm_cols[0]:
                    st.warning("⚠️ Are you sure you want to delete your account?")
                
                with confirm_cols[1]:
                    if st.button("✔️ Yes, Delete", key="confirm_delete", type="primary"):
                        try:
                            # Get current user's email
                            user_email = st.session_state.user.email
                            
                            # Call delete_account method from UserManager
                            success = st.session_state.user_manager.delete_account(user_email)
                            
                            if success:
                                # First clear user-specific session state
                                if 'user' in st.session_state:
                                    del st.session_state.user
                                if 'authenticated' in st.session_state:
                                    del st.session_state.authenticated

                                # Clear delete confirmation state
                                if 'show_delete_confirm' in st.session_state:
                                    del st.session_state.show_delete_confirm
                                st.session_state.clear()

                                # Set a flag to show success message on login page
                                st.session_state.show_deletion_success = True

                                # Finally, redirect to the login page
                                st.session_state.current_page = "Welcome"
                                st.rerun()

                            else:
                                st.error("Failed to delete account. Please try again.")
                                
                        except Exception as e:
                            st.error(f"Error deleting account: {str(e)}")
                            st.info("Please try again or contact support if the problem persists.")
                
                with confirm_cols[2]:
                    if st.button("❌ Cancel", key="cancel_delete"):
                        st.session_state.show_delete_confirm = False
                        st.rerun()
                    
            # Profile Data Section
            if hasattr(user, 'profile_data'):
                with st.expander("🔍 Profile Data", expanded=False):
                    st.json(user.profile_data)

            # Posts Section
            if user.posts:
                st.markdown('<div class="content-section">', unsafe_allow_html=True)
                st.subheader("📝 Your Posts")
                for post in user.posts:
                    with st.container():
                        st.caption(f"Posted on {post['timestamp']}")
                        st.markdown(post["content"])
                        st.divider()
                st.markdown('</div>', unsafe_allow_html=True)

            # Videos Section
            if user.videos:
                st.markdown('<div class="content-section video-section">', unsafe_allow_html=True)
                st.subheader("🎥 Your Videos")
                for video in user.videos:
                    with st.container():
                        st.caption(f"Added on {video['timestamp']}")
                        st.video(video["url"])
                        st.divider()
                st.markdown('</div>', unsafe_allow_html=True)

            # Stories Section
            if user.stories:
                st.markdown('<div class="content-section story-section">', unsafe_allow_html=True)
                st.subheader("📚 Your Stories")
                for story in user.stories:
                    with st.container():
                        st.caption(f"Posted on {story['timestamp']}")
                        st.markdown(story["content"])
                        st.divider()
                st.markdown('</div>', unsafe_allow_html=True)

    elif menu == "Explore":
    # Page Title with Styling
        st.markdown("<h1 style='text-align: center; color:White;'>🌍 Explore Posts</h1>", unsafe_allow_html=True)
        st.markdown("<p style='text-align: center; color: #666; font-size:26px;'>Discover what's trending in the community</p>", unsafe_allow_html=True)
        st.markdown("<hr style='border: 1px solid #ddd;'>", unsafe_allow_html=True)

        # Custom CSS for Styling Posts
        st.markdown("""
        <style>
    .post-card {
        background-color: #6c5b7b;
        padding: 2rem; /* Increased padding for better spacing */
        border-radius: 12px;
        box-shadow: 0 6px 10px rgba(0, 0, 0, 0.15);
        margin: 1.5rem 0;
    }
    .post-header {
        font-size: 24px; /* Increased for better readability */
        font-weight: bold;
        color: #2c3e50;
        margin-bottom: 0.8rem;
    }
    .post-content {
        font-size: 20px; /* Larger text for better visibility */
        color: #333;
        line-height: 1.6; /* Improved spacing for readability */
        margin-top: 0.5rem;
    }
    .post-timestamp {
        font-size: 16px; /* Bigger and clearer */
        font-weight: 500;
        color:black;
        margin-top: 1rem;
        text-align: right;
        font-style: italic;
    }
    .separator {
        border-top: 3px solid #ccc; /* Thicker for better separation */
        margin: 1.5rem 0;
    }
</style>

    """, unsafe_allow_html=True)

        # Function to Fetch All Posts & Videos
        def fetch_all_posts():
            all_posts = []
            if hasattr(st.session_state, "user_manager") and st.session_state.user_manager.users:
                for user in st.session_state.user_manager.users.values():
                    if hasattr(user, "posts") and user.posts:
                        for post in user.posts:
                            all_posts.append({
                            "type": "📝 Post",
                            "author": user.username,
                            "content": post["content"],
                            "timestamp": post["timestamp"]
                        })
                    if hasattr(user, "videos") and user.videos:
                        for video in user.videos:
                            all_posts.append({
                            "type": "🎥 Video",
                            "author": user.username,
                            "content": video["url"],
                            "timestamp": video["timestamp"]
                        })
            return sorted(all_posts, key=lambda x: x["timestamp"], reverse=True)  # Sort by newest first

        # Fetch & Store Posts in Session
        st.session_state.all_posts = fetch_all_posts()

            # Display Posts with Improved UI
        if st.session_state.all_posts:
            for post in st.session_state.all_posts:
                st.markdown(f"""
                <div class="post-card">
                    <div class="post-header">{post['type']} by `{post['author']}`</div>
                    <div class="post-content">{post['content']}</div>
                    <div class="post-timestamp">📅 {post['timestamp']}</div>
                </div>
            """, unsafe_allow_html=True)
            st.markdown("<div class='separator'></div>", unsafe_allow_html=True)  # Separator Line
        else:
            st.info("🚀 No posts available. Be the first to share something!")

    elif menu == "Search":
        # Load Custom CSS
        load_css("search.css")
        
        # Stylish Title
        st.markdown('<h1 class="search-title">🔍 Search Users by Secret Key</h1>', unsafe_allow_html=True)

        # Ensure UserManager is initialized
        if "user_manager" not in st.session_state:
            st.session_state.user_manager = UserManager()
            st.session_state.user_manager.add_user("test123", ["account1", "account2"])  # Test Data

        # Search Box
        st.markdown('<div class="search-box">', unsafe_allow_html=True)
        secret_key = st.text_input("", placeholder="Enter Secret Key...", key="secret_key_input")
        st.markdown('</div>', unsafe_allow_html=True)

        # Search Button
        if st.button("Search", key="search_button"):  
            accounts, profile_data = st.session_state.user_manager.search_by_secret_key(secret_key)

            if accounts:
                # Display Linked Accounts in a Card
                st.markdown('<div class="account-card">', unsafe_allow_html=True)
                st.markdown("<h3>🔗 Linked Accounts</h3>", unsafe_allow_html=True)
                for account in accounts:
                    st.markdown(f"<p>✅ {account}</p>", unsafe_allow_html=True)
                st.markdown('</div>', unsafe_allow_html=True)

                # Display Account Information in a Separate Card
                if profile_data:
                    st.markdown('<div class="profile-card">', unsafe_allow_html=True)
                    st.markdown("<h3>📜 Account Information</h3>", unsafe_allow_html=True)
                    st.markdown(f"<p>{profile_data}</p>", unsafe_allow_html=True)
                    st.markdown('</div>', unsafe_allow_html=True)
            else:
                st.markdown('<p class="error-msg">❌ No accounts found with this Secret Key</p>', unsafe_allow_html=True)
    elif menu == "add account":
        st.title("Create Additional Account")
    
        # Step 1: Token ID Validation
        token_id = st.text_input("Enter Token ID")
        col1, col2 = st.columns([1, 3])
        
        with col1:
            verify_token = st.button("Verify Token ID")
        
        if verify_token:
            try:
                user_manager = st.session_state.user_manager
                if token_id and token_id in user_manager.token_to_user:
                    email = user_manager.token_to_user[token_id]
                    user = user_manager.users[email]
                    st.session_state.token_valid = True
                    st.session_state.current_email = email
                    st.success("Token ID is valid. You can now send OTP.")
                else:
                    st.session_state.token_valid = False
                    st.error("Token ID not found. Please enter a valid Token ID.")
            except Exception as e:
                st.error(f"Error validating token: {str(e)}")
                st.session_state.token_valid = False
        
        # Step 2: OTP Generation and Sending
        if st.session_state.token_valid:
            with col2:
                if st.button("Send OTP", key="send_otp"):
                    try:
                        user_manager = st.session_state.user_manager
                        email = st.session_state.current_email
                        
                        if not email or email not in user_manager.users:
                            st.error("User data not found. Please verify token again.")
                            st.session_state.token_valid = False
                            return
                        
                        # Generate and store OTP
                        otp = str(secrets.randbelow(900000) + 100000)
                        st.session_state.generated_otp = hashlib.sha256(otp.encode()).hexdigest()
                        st.session_state.otp_timestamp = time.time()
                        st.session_state.otp_sent = True
                        st.session_state.otp_attempts = 0
                        
                        # Send OTP via email
                        if send_email_otp(email, otp,PASSWORD):
                            st.success(f"OTP sent to {email}")
                        else:
                            reset_otp_state()
                            st.error("Failed to send OTP. Please try again.")
                    
                    except Exception as e:
                        reset_otp_state()
                        st.error(f"Error sending OTP: {str(e)}")
        
        # Step 3: OTP Verification
        if st.session_state.otp_sent and not st.session_state.otp_verified:
            otp_input = st.text_input("Enter OTP", type="password")
            
            if st.button("Verify OTP"):
                try:
                    if time.time() - st.session_state.otp_timestamp > 120:
                        st.error("OTP has expired. Please request a new one.")
                        reset_otp_state()
                        return
                    
                    if st.session_state.otp_attempts >= 3:
                        st.error("Too many failed attempts. Please request a new OTP.")
                        reset_otp_state()
                        return
                    
                    hashed_input = hashlib.sha256(otp_input.encode()).hexdigest()
                    if hashed_input == st.session_state.generated_otp:
                        st.session_state.otp_verified = True
                        st.success("OTP verified successfully!")
                    else:
                        st.session_state.otp_attempts += 1
                        remaining_attempts = 3 - st.session_state.otp_attempts
                        st.error(f"Invalid OTP. {remaining_attempts} attempts remaining.")
                
                except Exception as e:
                    reset_otp_state()
                    st.error(f"Error verifying OTP: {str(e)}")
        
        # Step 4: Account Creation
        if st.session_state.otp_verified:
            new_username = st.text_input("New Username")
            
            if st.button("Create Account"):
                try:
                    if not new_username:
                        st.error("Please enter a username.")
                        return
                    
                    user_manager = st.session_state.user_manager
                    
                    # Check if username exists in any user's accounts
                    username_exists = False
                    for user in user_manager.users.values():
                        if new_username in user.accounts:
                            username_exists = True
                            break
                    
                    if username_exists:
                        st.error("Username already exists. Please choose another username.")
                        return
                    

                    updated_user = user_manager.create_additional_account(token_id, new_username)
                   
                    if updated_user and hasattr(updated_user, 'accounts'):
                        st.success("Account created successfully!")
                        st.write("Your accounts:", updated_user.accounts)
                    else:
                        st.error("Failed to create account. Please try again.")
                    
                    # Reset all states after successful account creation
                    st.session_state.token_valid = False
                    st.session_state.current_email = None
                    reset_otp_state()
                
                except Exception as e:
                    st.error(f"Error creating account: {str(e)}")
                    
    elif menu == "Logout":
        if not st.session_state.logout_clicked:
            st.success("You have been logged out.")
            st.session_state.logout_clicked = True
            st.session_state.redirect_time = time.time()
        elif time.time() - st.session_state.redirect_time >= 2:
            st.session_state.logged_in = False
            st.session_state.user = None
            st.session_state.current_page = "Welcome"
            st.session_state.logout_clicked = False
            st.session_state.redirect_time = None
            reset_form_state()
            st.rerun()

if 'performance_metrics' not in st.session_state:
    st.session_state.performance_metrics = {
        "login_times": [],
        "registration_times": []
    }

# Apply custom CSS for compact and stylish textbox with animation
st.markdown("""
<style>
    /* Enhanced Input Styling */
    .stTextInput > div > div > input {
        background:white !important;
        color: black !important; 
        border-radius: 8px !important;
        padding: 6px 10px !important;
        font-size: 14px !important;
        font-weight: bold !important;
        box-shadow: 0px 3px 6px rgba(0, 0, 0, 0.2) !important;
        transition: all 0.3s ease-in-out !important;
        border: 1px solid #00BFFF !important; /* Deep Sky Blue Border */
    }

    .stTextInput > div > div > input:focus {
        box-shadow: 0 0 10px #00BFFF !important;
        border: 2px solid #00BFFF !important;
    }

    /* Compact and Stylish Blue Navigation Buttons */
    .stButton > button {
        background: linear-gradient(135deg, #007FFF, #00BFFF) !important; /* Deep Sky Blue */
        color: #FFFFFF !important;
        border-radius: 6px !important;
        padding: 4px 8px !important;  /* Reduced padding */
        font-size: 12px !important;   /* Smaller font */
        font-weight: bold !important;
        margin: 3px 0 !important;
        transition: all 0.3s ease-in-out !important;
        box-shadow: 0px 3px 6px rgba(0, 0, 0, 0.3) !important;
        border: none !important;
    }

    .stButton > button:hover {
        background: linear-gradient(135deg, #005BBB, #008CFF) !important; /* Darker blue hover */
        transform: scale(1.05) !important;
        box-shadow: 0px 5px 10px rgba(0, 191, 255, 0.4) !important;
    }

    .stButton > button:active {
        transform: scale(0.95) !important;
    }

    /* Neon Button in Blue */
    .neon-button {
        position: fixed;
        left: 50%;
        bottom: 20%;
        transform: translateX(-50%);
        padding: 10px 30px;
        font-size: 18px;
        font-family: Arial, sans-serif;
        color: #4dffff; /* Cyan */
        background: rgba(0, 191, 255, 0.1); /* Light Blue */
        border: 1px solid #00ffff;
        border-radius: 25px;
        cursor: pointer;
        text-shadow: 0 0 5px #00ffff;
        box-shadow: 0 0 10px rgba(0, 191, 255, 0.5);
        transition: all 0.3s ease;
        opacity: 0;
    }

    .neon-button:hover {
        background: rgba(0, 191, 255, 0.2);
        box-shadow: 0 0 20px rgba(0, 191, 255, 0.8);
        text-shadow: 0 0 10px #00ffff;
    }

    /* Vibrant Sidebar with Glassmorphism in Blue */
    .sidebar .block-container {
        position: fixed !important;
        top: 0 !important;
        left: 0 !important;
        height: 100% !important;
        width: 200px !important;
        background: rgba(0, 102, 204, 0.9) !important; /* Deep Blue */
        backdrop-filter: blur(15px) !important; /* Glass Effect */
        color: #FFFFFF !important;
        z-index: 1000 !important;
        text-align: left !important;
        padding: 15px !important;
        box-shadow: 4px 0px 10px rgba(0, 0, 0, 0.3) !important;
        border-right: 2px solid rgba(255, 255, 255, 0.2) !important;
    }

    /* Stylish Scrollbar */
    ::-webkit-scrollbar {
        width: 6px; /* Slimmer scrollbar */
    }

    ::-webkit-scrollbar-thumb {
        background: linear-gradient(135deg, #007FFF, #00BFFF); /* Blue Gradient */
        border-radius: 6px;
    }

    ::-webkit-scrollbar-track {
        background: #F5F5F5;
    }
</style>
""", unsafe_allow_html=True)

if __name__ == "__main__":
        main()
