from solcx import get_solc_version
print(get_solc_version())  # Should print: 0.8.19
